// components/ProductsPage.js
import React from 'react';
import Products from '../screens/Product';

const ProductsPage = () => {
    return <Products />;
};

export default ProductsPage;